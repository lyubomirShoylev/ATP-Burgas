﻿using System;
using System.Collections.Generic;
using System.Text;

namespace fluelo.Models
{
    public class FuelModel
    {
        public string status { get; set; }
        public string fuel { get; set; }
        public decimal price { get; set; }
        public string dimension { get; set; }
        public string date { get; set; }
    }
}

//{
//    "status":"OK",
//    "fuel":"gasoline",
//    "price":2.61,
//    "dimension":"лв./л",
//    "date":"2013-09-16"
//}
