﻿using System;
using System.Collections.Generic;
using System.Text;

namespace fluelo.Models
{
    public class NewsModel
    {
        public string status { get; set; }
        public List<News> news { get; set; }
    }

    public class News
    {
        public int id { get; set; }
        public string date { get; set; }
        public string type { get; set; }
        public string brand { get; set; }
        public string fuel { get; set; }
        public string text { get; set; }

    }
}

//"status":"OK",
//    "news":[
//        {
//            "id":"1275",
//            "date":"2014-05-28 09:00:09",
//            "type":"fuel",
//            "brand":null,
//            "fuel":"lpg",
//            "text":"Пропан-бутанът поскъпна средно с 3ст. до 1,16лв./л"
//        },
