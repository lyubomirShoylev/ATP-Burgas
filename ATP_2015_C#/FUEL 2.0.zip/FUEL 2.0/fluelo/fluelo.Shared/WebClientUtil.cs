﻿using fluelo.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace fluelo
{
    public class WebClientUtil
    {
        public static readonly Dictionary<string,string> FuelTypesDictionary = new Dictionary<string,string>()
        {
	        {"lpg", "Пропан-Бутан"},
	        {"gasoline", "Бензин"},
	        {"diesel", "Дизел"},
	        {"methane", "Метан"}
	    };
        public static readonly string APIKey = "28bac3495f1d8bf";
        private static async Task<string> ReadDataFromWeb(string url)
        {
            var client = new HttpClient(); // Add: using System.Net.Http;
            var response = await client.GetAsync(new Uri(url));
            var result = await response.Content.ReadAsStringAsync();

            return result;
        }

        private static async Task<List<string>> GetFuelPriceJSON()
        {
            List<string> JsonFuels = new List<string>();
            List<string> FuelTypes = new List<string>() { "gasoline", "diesel", "lpg", "methane" };
            foreach(string fuel in FuelTypes)
            {
                string FuelQuery = "http://fuelo.net/api/price?key=" + APIKey + "&fuel="+fuel;
                JsonFuels.Add(await ReadDataFromWeb(FuelQuery));
                
            }
            return JsonFuels;
        }

        private static async Task<string> GetNewsJSON()
        {
            string NewsQuery = "http://fuelo.net/api/news?key=" + APIKey + " &count=30";
            return await ReadDataFromWeb(NewsQuery);
        }

        public static async Task<NewsModel> GetNews()
        {
            string JSONData = await GetNewsJSON();
            var News = JsonConvert.DeserializeObject<NewsModel>(JSONData);

            foreach(var singleNews in News.news)
            {
                singleNews.text = singleNews.text.Replace("<br />", Environment.NewLine);
                singleNews.text = Regex.Replace(singleNews.text, @"<[^>]*>", String.Empty);
            }

            return News;
        }

        public static async Task<List<FuelModel>> GetFuelPrice()
        {
            List<string> JSONData = await GetFuelPriceJSON();
            List<FuelModel> FuelPrices = new List<FuelModel>();
            foreach(string json in JSONData)
            {
                FuelModel Parse = JsonConvert.DeserializeObject<FuelModel>(json);
                Parse.fuel = FuelTypesDictionary[Parse.fuel];
                FuelPrices.Add(Parse);
            }

            return FuelPrices;
        }
    }
}
