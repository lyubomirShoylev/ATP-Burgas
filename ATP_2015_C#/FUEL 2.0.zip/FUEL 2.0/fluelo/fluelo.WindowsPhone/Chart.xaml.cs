﻿using fluelo.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using WinRTXamlToolkit.Controls.DataVisualization.Charting;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace fluelo
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Chart : Page
    {
        public Chart()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            List<Test> test = new List<Test>();
            test.Add(new Test() { Name = "434", Amount = 40 });
            test.Add(new Test() { Name = "4e4", Amount = 10 });
            test.Add(new Test() { Name = "4r4", Amount = 30 });
            test.Add(new Test() { Name = "4j4", Amount = 60 });
            test.Add(new Test() { Name = "4z4", Amount = 10 });

           // (PriceChart.Series[0] as LineSeries).ItemsSource = test;
           //http://eren.ws/2013/10/15/using-graphs-and-charts-in-windows-store-apps-boredom-challenge-day-11/
        }
    }

    public class Test
    {
        public string Name { get; set; }
        public int Amount { get; set; }
    }
}
