﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class CustomerService
    {
        private NORTHWNDEntities _Db;

        public CustomerService ()
        {
            _Db = new NORTHWNDEntities();
        }

        public IEnumerable<Customers> GetAllEmployees()
        {
            IEnumerable<Customers> cust =
                from customer in _Db.Customers
                select customer;
            return cust;
        }
    }
}
