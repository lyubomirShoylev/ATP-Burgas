﻿using LyuboMvc.Models.AlchoholModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LyuboMvc.Controllers
{
    public class AlchoholController : Controller
    {
        // GET: Alchohol
        [HttpGet]
        public ActionResult InsertAlchohol()
        {
            AlchoholModel viewModel = new AlchoholModel();
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult ViewAlchohol(AlchoholModel vm)
        {
            if (ModelState.IsValid)
            {
                return View(vm);
            }
            else
            {
                return RedirectToAction("InsertAlchohol");
            }
        }
    }
}