﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using LyuboMvc.Resources;

namespace LyuboMvc.Models.AlchoholModels
{
    public class AlchoholModel
    {

        [StringLength(20,
            ErrorMessageResourceType= typeof(ValidationResources),
            ErrorMessageResourceName = "Length")]
        [Required(ErrorMessageResourceType=typeof(ValidationResources),
            ErrorMessageResourceName = "Required")]
        [Display(Name="Brand", ResourceType = typeof(AlchoholResources))]
        public string Brand { get; set; }

        [Range(5 , 100 ,
            ErrorMessageResourceType = typeof(ValidationResources),
            ErrorMessageResourceName = "Range")]
        [Required(ErrorMessageResourceType = typeof(ValidationResources),
            ErrorMessageResourceName = "Required")]
        [Display(Name = "Degrees", ResourceType = typeof(AlchoholResources))]
        public int? Degrees { get; set; }

        [Range(1, 100,
            ErrorMessageResourceType = typeof(ValidationResources),
            ErrorMessageResourceName = "Range")]
        [Required(ErrorMessageResourceType = typeof(ValidationResources),
            ErrorMessageResourceName = "Required")]
        [Display(Name = "Quantity", ResourceType = typeof(AlchoholResources))]
        public int? Quantity { get; set;  }

        [Range(200, 1000, 
            ErrorMessageResourceType = typeof(ValidationResources),
            ErrorMessageResourceName = "Range")]
        [Required(ErrorMessageResourceType = typeof(ValidationResources),
             ErrorMessageResourceName = "Required")]
        [Display(Name = "Volume", ResourceType = typeof(AlchoholResources))]
        public double? Volume { get; set; }

        [Range(5,100, 
            ErrorMessageResourceType = typeof(ValidationResources),
            ErrorMessageResourceName = "Range")]
        [Required(ErrorMessageResourceType = typeof(ValidationResources),
            ErrorMessageResourceName = "Required")]
        [Display(Name = "Price", ResourceType = typeof(AlchoholResources))]
        public decimal? Price { get; set; }
    }
}