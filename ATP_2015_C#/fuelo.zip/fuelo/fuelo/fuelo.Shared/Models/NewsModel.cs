﻿using System;
using System.Collections.Generic;
using System.Text;

namespace fuelo.Models
{
    public class NewsModel
    {
        public string status { get; set; }
        public List<News> news { get; set; }
    }
    public class News
    {
        public int id{ get; set; }
        public string date{ get; set; }
        public string type{ get; set; }
        public string brand{ get; set; }
        public string fuel{ get; set; }
        public string text{ get; set; }

    }
}