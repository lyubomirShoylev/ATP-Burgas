﻿using fuelo.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace fuelo
{
    public class WebClientUtil
    {
        public static readonly string APIkey = "28bac3495f1d8bf";
        private static async Task<string> ReadDataFromWeb(string url)
        {
            var client = new HttpClient(); // Add: using System.Net.Http;
            var response = await client.GetAsync(new Uri(url));
            var result = await response.Content.ReadAsStringAsync();

            return result;
        }
        private static async Task<string> GetNewsJSON()
        {
            string NewsQuery = "http://fuelo.net/api/news?key=" + APIkey + "&count=30";
            var News = await ReadDataFromWeb(NewsQuery);//
            return News;//2 lines == return await ReadDataFromWeb(NewsQuery);
        }

        public static async Task<NewsModel> GetNews()
        {
            string JSONData = await GetNewsJSON();
            var News = JsonConvert.DeserializeObject<NewsModel>(JSONData);
            
            foreach(var SingleNews in News.news)
            {
                SingleNews.text = SingleNews.text.Replace("<br />", Environment.NewLine);
                SingleNews.text = Regex.Replace(SingleNews.text, @"<[^>]*>", String.Empty);
            }

            return News;
        }
    }
}
