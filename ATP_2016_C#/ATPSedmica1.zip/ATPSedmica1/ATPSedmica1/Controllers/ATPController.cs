﻿using ATPSedmica1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ATPSedmica1.Controllers
{
    public class ATPController : Controller
    {
        // GET: ATP
        public ActionResult Kashon()
        {
            KashonModel viewModel = new KashonModel();
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult ZaqvkaKashon(KashonModel viewModel)
        {
            string message = string.Format(@"Заявката за кашон с размери {0}:{1}:{2},
                и маса {3}, цвят {4},  материал {5}, беше приета успешно!"
                , viewModel.Height, viewModel.Width, viewModel.Length,
                viewModel.Weight, viewModel.Colour, viewModel.Material);

            ViewBag.SuccessMessage = message; // <=> ViewData["SuccessMessage"] = message;(1 заявка) \/ TempData["stuff"] = asd;(1 заявка напред) \/ Session["stuff"] = asd;(за сесия, т.е след определено време се губи, трябва да се занулява "= null")


            return View();
        }
    }
}