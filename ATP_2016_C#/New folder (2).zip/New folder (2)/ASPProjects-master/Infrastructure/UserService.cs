﻿using DataAccess;
using CommonFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonFiles.DTO;

namespace Infrastructure
{
    public class UserService
    {
        private ATPEntities _dbContext;

        public UserService()
        {
            _dbContext = new ATPEntities();
        }

        public void InsertUser(UserDTO dto)
        {
            _dbContext.USER_NEW_NEW.Add(new USER_NEW_NEW()
            {
                ABOUT = dto.About,
                EMAIL = dto.Email,
                GENDER = dto.Gender,
                PASSWORD = dto.Password,
                SECRET_A = dto.SecretAnswer,
                SECRET_Q = dto.SecretQuestion,
                USERNAME = dto.Username
            });
            _dbContext.SaveChanges();
        }
    }
}
