﻿using ATPSedmica1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ATPSedmica1.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Registration()
        {
            UserModel viewModel = new UserModel();

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult Confirmed(UserModel viewModel)
        {
            string message = string.Format(
                "Formata vi be poluchena. Vashiqt akaunt na e-mail {0} nosi username {1}. Blagodarim za poseshtenieto!"
                , viewModel.Email, viewModel.Username);
            ViewBag.SuccessMessage = message;
            return View();
        }
    }
}