﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ATPSedmica1.Models
{
    public class UserModel
    {

        public string Username { get; set; }

        [Display(Name = "Password")]
        public string Password { get; set; }

        [Compare(nameof(Password), ErrorMessage = "Passwords do not match")]
        public string PasswordConfirm { get; set; }

        [EmailAddress(ErrorMessage = "Nimoj")]

        public string Email { get; set; }

        public Gender Gender { get; set; }

        public string About { get; set; }

        public string SecretQuestion { get; set; }

        public string SecretAnswer { get; set; }

    }

    public enum Gender
    {
        Male,
        Female,
        AttackHelicopter,
        Other
    }
}