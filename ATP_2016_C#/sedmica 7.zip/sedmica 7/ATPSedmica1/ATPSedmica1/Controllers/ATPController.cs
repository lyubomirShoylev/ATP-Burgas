﻿using ATPSedmica1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Infrastructure;
using ATP.Common.DTO;

namespace ATPSedmica1.Controllers
{
    public class ATPController : Controller
    {
        private BoxService _service;

        public ATPController()
        {
            _service = new BoxService();

        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            BoxDTO dto = _service.GetBox(id);
            return View(new KashonModel()
            {
                ID = dto.ID,
                Colour = dto.Color,
                Height = dto.Height,
                Length = dto.Length,
                Material = dto.Material,
                Weight = dto.Weight,
                Width = dto.Width
            }); 
        }

        [HttpPost]
        public ActionResult Edit(KashonModel viewModel)
        {
            if (ModelState.IsValid)
            {
                _service.EditBox(new BoxDTO()
                {
                    ID = viewModel.ID,
                    Color = viewModel.Colour,
                    Height=viewModel.Height,
                    Length=viewModel.Length,
                    Material=viewModel.Material,
                    Weight=viewModel.Weight,
                    Width=viewModel.Width
                });

                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Edit", new { id = viewModel.ID });
            }            
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            _service.DeleteBox(id);
            return RedirectToAction("List");
        }

        [HttpGet]
        public ActionResult List()
        {
            return View(_service.ListBoxes().Select(x=>new KashonModel()
            {
                Colour=x.Color,
                Height=x.Height,
                ID=x.ID,
                Length=x.Length,
                Material=x.Material,
                Weight=x.Weight,
                Width=x.Width
            }).ToList());
        }

        // GET: ATP
        public ActionResult Kashon()
        {
            KashonModel viewModel;
            if(TempData["viewModel"] != null)
            {
                viewModel = (KashonModel)TempData["viewModel"];
            } 
            else
            {
                viewModel = new KashonModel();
            }

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult ZaqvkaKashon(KashonModel viewModel)
        {
            //Validirame modela
            if (ModelState.IsValid)
            {
                string message = string.Format(@"Заявката за кашон с размери {0}:{1}:{2},
                и маса {3}, цвят {4},  материал {5}, беше приета успешно!"
                , viewModel.Height, viewModel.Width, viewModel.Length,
                viewModel.Weight, viewModel.Colour, viewModel.Material);

                ViewBag.SuccessMessage = message;
                // <=> ViewData["SuccessMessage"] = message;(1 заявка) \/ TempData["stuff"] = asd;(1 заявка напред) 
                // \/ Session["stuff"] = asd;(за сесия, т.е след определено време се губи, трябва да се занулява "= null")
                //this._models.Add(viewModel);

                _service.InsertBox(new BoxDTO()
                {
                    Color = viewModel.Colour,
                    Height = viewModel.Height,
                    Length = viewModel.Length,
                    Material = viewModel.Material,
                    Weight = viewModel.Weight,
                    Width = viewModel.Width
                });

                return View();
            }
            else
            {
                TempData["viewModel"] = viewModel;
                return RedirectToAction("Kashon");
            }
        }
    }
}