﻿using ATP.Common.DTO;
using ATPSedmica1.Models;
using Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ATPSedmica1.Controllers
{
    public class CVController : Controller
    {
        private CVService _service;
        // GET: CVView
        public CVController()
        {
            _service = new CVService();
        }

        public ActionResult NewCV()
        {
            CVViewModel viewModel;
            if (TempData["viewModel"] != null)
            {
                viewModel = (CVViewModel)TempData["viewModel"];
            }
            else viewModel = new CVViewModel();
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult ConfirmCV(CVViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                string message = string.Format("ti se kazvash {0} i podade svoeto CV. poluchavash vafla", viewModel.FirstName);
                ViewBag.SuccessMessage = message;

                _service.InsertCV(new CVDTO()
                {
                    ID = viewModel.ID,
                    FirstName = viewModel.FirstName,
                    LastName = viewModel.LastName,
                    Email = viewModel.Email,
                    Experience = viewModel.Experience,
                    Qualities = viewModel.Qualities,
                    Education = viewModel.Education,
                    Address = viewModel.Address,
                    PictureBytes = viewModel.PictureBytes,
                    PictureName = viewModel.PictureName
                });

                return View();
            }
            else
            {
                TempData["viewModel"] = viewModel;
                return RedirectToAction("NewCV");
            }
        }

        [HttpGet]
        public ActionResult ListCV()
        {
            return View(_service.ListCVs().Select(x => new CVViewModel()
            {
                ID = x.ID,
                FirstName = x.FirstName,
                LastName = x.LastName,
                Email = x.Email,
                Experience = x.Experience,
                Qualities = x.Qualities,
                Education = x.Education,
                Address = x.Address,
                PictureBytes = x.PictureBytes,
                PictureName = x.PictureName
            }).ToList());
        }
    }
}