﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ATPSedmica1.Models;
using reCaptcha;
using System.Configuration;
using Infrastructure;

namespace ATPSedmica1.Controllers
{
    public class SignUpController : Controller
    {
        // GET: SignUp
        public ActionResult Index()
        {
            return View();
        }

        
        public ActionResult SignUp()
        {
            SignUpModel model = new SignUpModel();
            if (TempData["model"] != null)
            {
                model = (SignUpModel)TempData["model"];
            }
           
            return View(model);
        }

        [HttpPost]
        public ActionResult SignedUp(SignUpModel model)
        {

            if (model.Agree && ModelState.IsValid && ReCaptcha.Validate("6Lf22AsUAAAAAF98bTCknrV02Q1AqWTgUXyyDvkm"))
            {
                new UserService().InsertUser(new ATP.Common.DTO.UserDTO()
                {
                    About = model.About,
                    Username = model.Username,
                    Password = model.PasswordV,
                    Email = model.Email,
                    Gender = model.Gender,
                    SecretA = model.SecretA,
                    SecretQ = model.SecretQ
                });
                ViewBag.SuccessMessage = ATP.Common.Resources.SignUpResources.SignUpMessage;
                return View(model);
            }
            else
            {
                ViewBag.RecaptchaLastErrors = ReCaptcha.GetLastErrors(HttpContext);

                ViewBag.publicKey = "";
                TempData["model"] = model;
                return RedirectToAction("SignUp");
            }
        }
    }
}