﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using ATP.Common.Resources;

namespace ATPSedmica1.Models
{
    public class KashonModel
    {

        //[Validaciq na danna]
        //danna{get;set}

        public int ID { get; set; }

        [Display(Name = "Colour", ResourceType = typeof(KashonResources))]
        [MaxLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(ErrorResources))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(ErrorResources))] 
        public string Colour { get; set; }

        [Display(Name = "Height", ResourceType = typeof(KashonResources))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public decimal Height { get; set; }
        // ? sled int = moje da e null

        [Display(Name = "Width", ResourceType = typeof(KashonResources))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public decimal Width { get; set; }

        [Display(Name = "Length", ResourceType = typeof(KashonResources))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public decimal Length { get; set; }

        [Display(Name = "Material", ResourceType = typeof(KashonResources))]
        [MaxLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(ErrorResources))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Material { get; set; }

        [Display(Name = "Weight", ResourceType = typeof(KashonResources))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public decimal Weight { get; set; }
    }
}