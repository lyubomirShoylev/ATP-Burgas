﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ATP.Common.Resources;
using reCaptcha;

namespace ATPSedmica1.Models
{
    public class MustBeTrueAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if(!(bool)value) return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            return null;
        }
    }
    public class SignUpModel
    {
        string id;
        public SignUpModel()
        {
            id = Guid.NewGuid().ToString();
            Agree = false;
            Genders.Add(new SelectListItem { Text = "Male", Value = "Male" });
            Genders.Add(new SelectListItem { Text = "Female", Value = "Female" });
            Questions.Add(new SelectListItem { Text = "How many friends do you have?", Value = "0" });
            Questions.Add(new SelectListItem { Text = "How many friends have you had?", Value = "1" });
            Questions.Add(new SelectListItem { Text = "What's the first method you have used?", Value = "2" });

            
        }

        [Display(Name = "Username", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        [MaxLength(30, ErrorMessageResourceName ="MaxLength", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Username { get; set; }

        [Display(Name = "Password", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        [MinLength(6,ErrorMessageResourceName = "MinLength", ErrorMessageResourceType = typeof(ErrorResources))]
        [System.ComponentModel.DataAnnotations.Compare("PasswordV")]
        public string Password { get; set; }

        [Display(Name = "PasswordV", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        [MinLength(6, ErrorMessageResourceName = "MinLength", ErrorMessageResourceType = typeof(ErrorResources))]
        [System.ComponentModel.DataAnnotations.Compare("Password")]
        public string PasswordV { get; set; }

        [Display(Name = "Email", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        [EmailAddress(ErrorMessageResourceName ="EmailAddress", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Email { get; set; }

        [Display(Name = "Gender", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public string Gender { get; set; }

        [Display(Name = "About", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public string About { get; set; }

        [Display(Name = "SecretQ", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public string SecretQ { get; set; }

        [Display(Name = "SecretA", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public string SecretA { get; set; }

        [Display(Name = "Agree", ResourceType = typeof(SignUpResources))]
        [Required(ErrorMessageResourceName ="Required", ErrorMessageResourceType = typeof(ErrorResources))]
        public bool Agree { get; set; }

        ReCaptcha captcha = new ReCaptcha();

        public List<SelectListItem> Genders = new List<SelectListItem>();

        public List<SelectListItem> Questions = new List<SelectListItem>();
    }
}