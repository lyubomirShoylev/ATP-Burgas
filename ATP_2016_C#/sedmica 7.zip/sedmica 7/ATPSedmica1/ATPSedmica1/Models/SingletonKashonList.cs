﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ATPSedmica1.Models
{
    public class SingletonKashonList
    {
        public static List<KashonModel> models;
        private static SingletonKashonList instance;
        private SingletonKashonList() { }
        public static SingletonKashonList Instance
        {
            get
            {
                if(instance == null)
                {
                    instance = new SingletonKashonList();
                }
                return instance;
            }
        }
        public static List<KashonModel> Models
        {
            get
            {
                if(models == null)
                {
                    models = new List<KashonModel>();
                    models.Add(new KashonModel()
                    {
                        Colour = "Зелено",
                        Height = 1,
                        Length = 5,
                        Width = 7,
                        Weight = 9,
                        Material = "Ракия"
                    });
                    models.Add(new KashonModel()
                    {
                        Colour = "Пембяно",
                        Height = 1132,
                        Length = 513,
                        Width = 723,
                        Weight = 139,
                        Material = "Велур"
                    });
                }
                return models;
            }
        }
    }
}