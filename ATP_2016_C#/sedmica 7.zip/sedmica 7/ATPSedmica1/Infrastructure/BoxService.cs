﻿using ATP.Common.DTO;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class BoxService
    {
        public void InsertBox(BoxDTO dto)
        {
            var dbContext = new ATPEntities();
            dbContext.BOX.Add(new BOX(){
                COLOR=dto.Color,
                HEIGHT=dto.Height,
                LENGTH=dto.Length,
                MATERIAL=dto.Material,
                WIDTH=dto.Width
            });
            dbContext.SaveChanges();
        }

        public void DeleteBox(int id)
        {
            var dbContext = new ATPEntities();
            dbContext.BOX.Remove(dbContext.BOX.Where(x => x.ID == id).SingleOrDefault());
            dbContext.SaveChanges();
        }
        
        public List<BoxDTO> ListBoxes()
        {
            var dbContext = new ATPEntities();
            return dbContext.BOX.Select(x => new BoxDTO()
            {
                Color = x.COLOR,
                ID = x.ID,
                Height = x.HEIGHT,
                Length = x.LENGTH,
                Material = x.MATERIAL,
                Weight = x.WEIGHT,
                Width = x.WIDTH
            }).ToList();
        }

        public BoxDTO GetBox(int id)
        {
            var dbContext = new ATPEntities();
            return dbContext.BOX.Select(x => new BoxDTO()
            {
                Color = x.COLOR,
                ID = x.ID,
                Height = x.HEIGHT,
                Length = x.LENGTH,
                Material = x.MATERIAL,
                Weight = x.WEIGHT,
                Width = x.WIDTH
            }).SingleOrDefault(x => x.ID == id);
        }

        public void EditBox(BoxDTO dto)
        {
            var dbContext = new ATPEntities();
            var dbBox = dbContext.BOX.SingleOrDefault(x => x.ID == dto.ID);
            dbBox.HEIGHT = dto.Height;
            dbBox.COLOR = dto.Color;
            dbBox.ID = dto.ID;
            dbBox.LENGTH = dto.Length;
            dbBox.MATERIAL = dto.Material;
            dbBox.WEIGHT = dto.Weight;
            dbBox.WIDTH = dto.Width;
            dbContext.SaveChanges();
        }
    }
}
