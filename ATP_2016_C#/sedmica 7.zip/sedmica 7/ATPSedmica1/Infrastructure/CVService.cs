﻿using ATP.Common.DTO;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class CVService
    {
        ATPEntities _dbContext;

        public CVService()
        {
            _dbContext = new ATPEntities();
        }

        public List<CVDTO> ListCVs()
        {
            return _dbContext.CV.Select(x => new CVDTO()
            {
                ID = x.ID,
                FirstName = x.FirstName,
                LastName = x.LastName,
                Email = x.Email,
                Experience = x.Experience,
                Qualities = x.Qualities,
                Education = x.Education,
                Address = x.Address,
                PictureBytes = x.Picture,
                PictureName = x.PictureName
            }).ToList();
        }

        public CVDTO CVGet(int id)
        {
            return _dbContext.CV.Select(x => new CVDTO()
            {
                ID = x.ID,
                FirstName = x.FirstName,
                LastName = x.LastName,
                Email = x.Email,
                Experience = x.Experience,
                Qualities = x.Qualities,
                Education = x.Education,
                Address = x.Address,
                PictureBytes = x.Picture,
                PictureName = x.PictureName
            }).SingleOrDefault(x => x.ID == id);
        }

        public void DeleteCV(int id)
        {
            _dbContext.CV.Remove(_dbContext.CV.SingleOrDefault(x => x.ID == id));
            _dbContext.SaveChanges();
        }

        public void InsertCV(CVDTO dto)
        {
            _dbContext.CV.Add(new CV()
            {
                ID = dto.ID,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                Experience = dto.Experience,
                Qualities = dto.Qualities,
                Education = dto.Education,
                Address = dto.Address,
                Picture = dto.PictureBytes,
                PictureName = dto.PictureName
            });
            _dbContext.SaveChanges();
        }

        public void Update(CVDTO dto)
        {
            var CV = _dbContext.CV.SingleOrDefault(x => x.ID == dto.ID);
            CV.ID = dto.ID;
            CV.FirstName = dto.FirstName;
            CV.LastName = dto.LastName;
            CV.Email = dto.Email;
            CV.Experience = dto.Experience;
            CV.Qualities = dto.Qualities;
            CV.Education = dto.Education;
            CV.Address = dto.Address;
            CV.Picture = dto.PictureBytes;
            CV.PictureName = dto.PictureName;

            _dbContext.SaveChanges();
        }
    }
}
