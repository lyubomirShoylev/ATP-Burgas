﻿using ATPSedmica1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ATPSedmica1.Controllers
{
    public class ATPController : Controller
    {
        private List<KashonModel> _models;

        public ATPController()
        {
            _models = SingletonKashonList.Models;
            
        }

        [HttpGet]
        public ActionResult Edit(string id)
        {
            KashonModel model = _models
                .Where(x => x.ID == id)
                .FirstOrDefault();
            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(KashonModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var Old = _models
                    .Where(x => x.ID == viewModel.ID)
                    .FirstOrDefault();

                Old.Colour = viewModel.Colour;
                Old.Material = viewModel.Material;
                Old.Height = viewModel.Height;
                Old.Length = viewModel.Length;
                Old.Width = viewModel.Width;
                Old.Weight = viewModel.Weight;

                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Edit", new { id = viewModel.ID });
            }            
        }

        [HttpGet]
        public ActionResult Delete(string id)
        {
            _models.Remove(_models.Where(x => x.ID == id).FirstOrDefault());
            return RedirectToAction("List");
        }

        [HttpGet]
        public ActionResult List()
        {
            return View(_models);
        }

        // GET: ATP
        public ActionResult Kashon()
        {
            KashonModel viewModel;
            if(TempData["viewModel"] != null)
            {
                viewModel = (KashonModel)TempData["viewModel"];
            } 
            else
            {
                viewModel = new KashonModel();
            }

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult ZaqvkaKashon(KashonModel viewModel)
        {
            //Validirame modela
            if (ModelState.IsValid)
            {
                string message = string.Format(@"Заявката за кашон с размери {0}:{1}:{2},
                и маса {3}, цвят {4},  материал {5}, беше приета успешно!"
                , viewModel.Height, viewModel.Width, viewModel.Length,
                viewModel.Weight, viewModel.Colour, viewModel.Material);

                ViewBag.SuccessMessage = message;
                // <=> ViewData["SuccessMessage"] = message;(1 заявка) \/ TempData["stuff"] = asd;(1 заявка напред) 
                // \/ Session["stuff"] = asd;(за сесия, т.е след определено време се губи, трябва да се занулява "= null")
                this._models.Add(viewModel);

                return View();
            }
            else
            {
                TempData["viewModel"] = viewModel;
                return RedirectToAction("Kashon");
            }
        }
    }
}